document.addEventListener("DOMContentLoaded", () => {

    const surface = document.getElementById("drone-surface");
    const drone = document.createElement("div");
    drone.className = "drone";
    surface.appendChild(drone);

    // Keep track of drone placement
    let dronePlaced = false;

    let x = 0;
    let y = 0;
    let facing = "NORTH";

   const executeCommand = () => {
    const commandInput = document.getElementById("commandInput");
    const command = commandInput.value.toUpperCase();

    if (command.startsWith("PLACE")) {
        const params = command.split(" ")[1].split(",");
        const newX = parseInt(params[0]);
        const newY = parseInt(params[1]);
        const newFacing = params[2];

        const validCoordinates = !isNaN(newX) && !isNaN(newY) && isValidPosition(newX, newY);
        const validFacing = ["NORTH", "SOUTH", "EAST", "WEST"].includes(newFacing);

        if (validCoordinates && validFacing) {
            x = newX;
            y = newY;
            facing = newFacing;
            dronePlaced = true;
            drone.style.display = "block"; // Make the drone visible
            updateDronePosition();
        } else {
            alert("Invalid PLACE command. Please enter valid coordinates (0-9) and a valid facing direction (NORTH, SOUTH, EAST, WEST).");
        }
    } else {
        // Check if drone is placed before executing other commands
        if (!dronePlaced) {
            alert("Drone must be placed before executing other commands.");
            return;
        }

        switch (command) {
            case "MOVE":
                moveDrone();
                break;
            case "LEFT":
            case "RIGHT":
                rotateDrone(command);
                break;
            case "ATTACK":
                attack();
                break;
            case "REPORT":
                reportDrone();
                break;
            default:
                alert("Invalid command. Please enter a valid command.");
                break;
        }
    }

    commandInput.value = ""; // Clear the input field
};



    //Check if drone is placed on the surface
    const isDronePlaced = () => {
        return typeof x !== 'undefined' && typeof y !== 'undefined' && typeof facing !== 'undefined';
    };

    //Execute MOVE command
    window.moveDrone = () => {
        if (dronePlaced) {
            let newX = x;
            let newY = y;

            switch (facing) {
                case "NORTH":
                    newY = Math.min(y + 1, 9);
                    break;
                case "SOUTH":
                    newY = Math.max(y - 1, 0);
                    break;
                case "EAST":
                    newX = Math.min(x + 1, 9);
                    break;
                case "WEST":
                    newX = Math.max(x - 1, 0);
                    break;
            }

            if (isValidPosition(newX, newY)) {
                x = newX;
                y = newY;
                updateDronePosition();
            }
        }
    };

    //Execute LEFT or RIGHT command
    window.rotateDrone = (direction) => {
        if (dronePlaced) {
            const directions = ["NORTH", "EAST", "SOUTH", "WEST"];
            const currentIndex = directions.indexOf(facing);

            if (direction === "LEFT") {
                facing = directions[(currentIndex + 3) % 4];
            } else if (direction === "RIGHT") {
                facing = directions[(currentIndex + 1) % 4];
            }

            updateDronePosition();
        }
    };

    //REPORT command
    window.reportDrone = () => {
        if (dronePlaced) {
            const output = document.getElementById("output");
            output.textContent = `Drone position: X=${x}, Y=${y}, Facing=${facing}`;
        }
    };

    //ATTACK command
    window.attack = () => {
        if (dronePlaced) {
            let projectileX = x;
            let projectileY = y;

            switch (facing) {
                case "NORTH":
                    projectileY += 2;
                    break;
                case "SOUTH":
                    projectileY -= 2;
                    break;
                case "EAST":
                    projectileX += 2;
                    break;
                case "WEST":
                    projectileX -= 2;
                    break;
            }

            if (isValidPosition(projectileX, projectileY)) {
                // Play explosion sound
                const explosionSound = document.getElementById("explosionSound");
                explosionSound.play();

                const explosion = document.createElement("div");
                explosion.className = "explosion";
                surface.appendChild(explosion);
              
                explosion.style.left = `${projectileX * 30}px`;
                explosion.style.top = `${(9 - projectileY) * 30}px`;

                setTimeout(() => {
                    surface.removeChild(explosion);
                }, 1000);
            }
        }
    };

    const isValidPosition = (newX, newY) => {
        return newX >= 0 && newX <= 9 && newY >= 0 && newY <= 9;
    };

    let currentRotation = 0; 

    //Update drone position and rotation
    const updateDronePosition = () => {
        drone.style.left = `${x * 30}px`;
        drone.style.top = `${(9 - y) * 30}px`;

        let targetRotation;
        switch (facing) {
            case "NORTH":
                targetRotation = 0;
                break;
            case "EAST":
                targetRotation = 90;
                break;
            case "SOUTH":
                targetRotation = 180;
                break;
            case "WEST":
                targetRotation = 270;
                break;
            default:
                targetRotation = 0;
                break;
        }

        const rotationDifference = targetRotation - currentRotation;
        const normalizedRotation = (rotationDifference + 540) % 360 - 180;

        currentRotation += normalizedRotation;
        drone.style.transform = `rotate(${currentRotation}deg)`;
    };
  
    window.executeCommand = executeCommand;
});
